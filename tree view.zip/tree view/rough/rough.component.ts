import { Component, OnInit } from '@angular/core';
import { DummyDataComponent } from '../Dummy_Data/dummyData'

@Component({
  selector: 'app-rough',
  templateUrl: './rough.component.html',
  styleUrls: ['./rough.component.css'],
})
export class RoughComponent implements OnInit{

  jsonData = this.apiData.userData;
  constructor(private apiData: DummyDataComponent) {};

  func(item : any) : any {
    for(let entry of Object.entries(this.jsonData)) {
      if(entry[1].name === item ){
        for(let val of this.jsonData){
          if(Object.values(val).indexOf(entry[1].name) > -1)
            return true;
          // console.log(Object.values(val).indexOf(entry[1].name) > -1);
        }
      }
      else if(entry[1].childCount > 0)
        return this.test(entry[1].childs);
      return false;
    }
  }

  test(val : any) : any {
    for(let ele of val) {
      // if()
    }
  }

  ngOnInit(): void {
    // console.log(this.jsonData)
  }
}
