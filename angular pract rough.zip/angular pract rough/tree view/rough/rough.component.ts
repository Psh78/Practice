import { Component, OnInit } from '@angular/core';
import { DummyDataComponent } from '../Dummy_Data/dummyData'

@Component({
  selector: 'app-rough',
  templateUrl: './rough.component.html',
  styleUrls: ['./rough.component.css'],
})
export class RoughComponent implements OnInit{

  jsonData = this.apiData.userData;
  constructor(private apiData: DummyDataComponent) {};

  func(item : any) : any {
    for(let entry of Object.entries(this.jsonData)) {
      // console.log(entry[1].childCount);
      // if(entry[1].name === item && this.jsonData.indexOf(entry[1].name))
      if(entry[1].name === item ){
        // console.log(this.jsonData.includes(entry[1].name));
        return true;
      }
      else if(entry[1].childCount > 0)
        return this.func(entry[1].childs);
      return true
    }
  }

  ngOnInit(): void {
    // console.log(this.jsonData)
  }
}
